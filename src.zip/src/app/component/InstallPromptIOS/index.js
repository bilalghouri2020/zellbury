export { default } from './InstallPromptIOS.component';
