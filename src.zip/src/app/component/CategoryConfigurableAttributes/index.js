export { default } from './CategoryConfigurableAttributes.container';
