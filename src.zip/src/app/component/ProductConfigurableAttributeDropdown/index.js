export { default } from './ProductConfigurableAttributeDropdown.container';
