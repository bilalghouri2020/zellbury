export { default } from './CashBackToggle.component';
