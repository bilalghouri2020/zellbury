/* eslint-disable import/prefer-default-export */
export const OVERLAY_PLACEHOLDER = 'OVERLAY_PLACEHOLDER';
