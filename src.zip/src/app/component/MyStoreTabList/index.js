export { default } from './MyStoreTabList.container';
