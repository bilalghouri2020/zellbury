export { default } from './InstallPromptAndroid.component';
