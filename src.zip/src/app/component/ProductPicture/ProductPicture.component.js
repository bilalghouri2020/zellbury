/**
 * ScandiPWA - Progressive Web App for Magento
 *
 * Copyright © Scandiweb, Inc. All rights reserved.
 * See LICENSE for license details.
 *
 * @license OSL-3.0 (Open Software License ("OSL") v. 3.0)
 * @package scandipwa/base-theme
 * @link https://github.com/scandipwa/base-theme
 */

 import './ProductPicture.style';

 import PropTypes from 'prop-types';
 import { PureComponent } from 'react';
 import Loader from 'Component/Loader';
 import { customerType } from 'Type/Account';
 import history from 'Util/History';
 import Webcam from "react-webcam";
 

 export class ProductPicture extends PureComponent {
     static propTypes = {
         customer: customerType.isRequired
     };

   

     webcamRef = React.createRef();

    dataURItoBlob = (dataURI) => {
        // convert base64 to raw binary data held in a string
        // doesn't handle URLEncoded DataURIs - see SO answer #6850276 for code that does this
        var byteString = atob(dataURI.split(',')[1]);
    
        // separate out the mime component
        var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    
        // write the bytes of the string to an ArrayBuffer
        var ab = new ArrayBuffer(byteString.length);
        var ia = new Uint8Array(ab);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
    
        //Old Code
        //write the ArrayBuffer to a blob, and you're done
        //var bb = new BlobBuilder();
        //bb.append(ab);
        //return bb.getBlob(mimeString);
    
        //New Code
        return new Blob([ab], {type: mimeString});
    
    
    }
    capture = () => {
        // const { updateComplain, complainData } = this.props;

        // console.log('pro', productOption);
        // console.log('pro1', this.props);
        // let obj = {
        //     complainData: complainData,
        //     barcodeMatchedData: productOption
        // }
        // updateComplain(obj);
        const { complainData, showNotification, productOption } = this.props;
        console.log("complainData", complainData);
        console.log("ds", productOption);
        let customer = JSON.parse(localStorage.getItem('customer'));
        const imageSrc = this.webcamRef.current.getScreenshot();
        console.log("imageSrc", imageSrc);
        var blob = this.dataURItoBlob(imageSrc);
        let imgFile = new File([blob], "image.jpg")
        var myHeaders = new Headers();
        myHeaders.append("Authorization", "Basic aGhsYXNxR1NZZDdSVVJzV2p4dWU6eGE=");
        myHeaders.append("Cookie", "_x_w=2");
        var formdata = new FormData();
        formdata.append("attachments[]", imgFile);
        formdata.append("cc_emails[]", ['waqas.pervez@zellbury.com']);
        formdata.append("email", `${customer.data.email}`);
        formdata.append("subject", `${productOption.mainOption}`);
        formdata.append("description", `Item is ${productOption.mainOption} from ${productOption.subOption}`);
        formdata.append("status", "2");
        formdata.append("priority", "1");
        formdata.append("type", "Product Related");

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };

        fetch("https://newaccount1631100479992.freshdesk.com/api/v2/tickets", requestOptions)
        .then(response => response.json())
        .then(result => {
            console.log("result", result);
            if(result.errors && result.errors.length){
                showNotification('error', __("Invalid Data"));
            }else{
                showNotification('success', __("Ticket Submitted Successfully"));
                history.push('/ordercomplain/delivered-orders/exchange-order');
            }
           
        })
        .catch(error => {
            console.log('error', error)
            showNotification('error', __("Image Upload Error"));
        });
        // var data = JSON.stringify({
        //     "cc_emails": [
        //       "waqas.pervez@zellbury.com"
        //     ],
        //     "email_config_id": null,
        //     "group_id": null,
        //     "priority": 1,
        //     "email": customer.data.email,
        //     "responder_id": null,
        //     "source": 2,
        //     "status": 2,
        //     "subject": subject,
        //     "type": "Product Related",
        //     "product_id": null,
        //     "description": `${addressVar}`,
        //     "tags": []
        //   });
          
        //   var config = {
        //     method: 'post',
        //     url: 'https://newaccount1631100479992.freshdesk.com/api/v2/tickets',
        //     headers: { 
        //       'Authorization': 'Basic aGhsYXNxR1NZZDdSVVJzV2p4dWU6eA==', 
        //       'Content-Type': 'application/json', 
        //       'Cookie': '_x_w=2'
        //     },
        //     data : data
        //   };
          
        //   axios(config)
        //   .then(function (response) {
        //     console.log(JSON.stringify(response.data));
        //     showNotification('success', __('Ticket Submitted Successfully'));
        //     history.push('/ordercomplain/orderslist');
        //   })
        //   .catch(function (error) {
        //     console.log(error);
        //   });
    }
     
     renderContent = () => {
        const videoConstraints = {
            width: 1280,
            height: 720,
            // facingMode: "user"
        };
        

        return (
            <div className="camSec">
                <Webcam
                    className="cameraSection"
                    audio={false}
                    height={320}
                    ref={this.webcamRef}
                    screenshotFormat="image/jpeg"
                    width={400}
                    videoConstraints={videoConstraints}
                />
                <div className="captureButtonSec">
                    <button
                        className="optionsBtn"
                        type="text"
                        onClick={this.capture}
                        block={"Capture"}
                        elem="Button"
                        mix={ { block: 'Button' } }
                        >
                            { __(`Capture photo`) }
                    </button>
                </div>
            </div>
        )
     }

     render() {
         return (
            <div>
                { this.renderContent() }
                {/* { this.renderConfirmPopup() } */}
            </div>
         )
         
     }
 }
 
 export default ProductPicture;