
import './GiftcartPopup.style';
import { PureComponent } from 'react';
export class GiftcartPopup extends PureComponent {
   
}

export default GiftcartPopup;
