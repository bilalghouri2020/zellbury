export const TRANSFORMATION_DELAY = 0;
export const TRANSFORMATION_SPEED = 0;
export const INITIAL_SCALE = 1;
