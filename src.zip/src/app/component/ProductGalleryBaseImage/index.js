export { default } from './ProductGalleryBaseImage.container';
