export { default } from './TierPrices.component';
