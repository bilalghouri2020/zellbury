export const observerThreshold = 10;

export const INTERSECTION_RATIO = 0.5;
