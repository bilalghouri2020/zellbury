export { default } from './NavigationTabs.container';
