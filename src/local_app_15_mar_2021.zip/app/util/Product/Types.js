export const CONFIGURABLE = 'configurable';
export const GROUPED = 'grouped';
export const SIMPLE = 'simple';
export const BUNDLE = 'bundle';
