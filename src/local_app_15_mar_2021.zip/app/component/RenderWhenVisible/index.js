export { default } from './RenderWhenVisible.component';
