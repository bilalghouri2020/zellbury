export { default } from './NotSupportedPayment.component';
