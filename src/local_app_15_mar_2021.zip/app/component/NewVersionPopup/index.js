export { default } from './NewVersionPopup.container';
